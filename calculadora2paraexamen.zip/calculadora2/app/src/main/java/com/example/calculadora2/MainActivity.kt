package com.example.calculadora2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var et1: EditText
    lateinit var et2: EditText
    lateinit var tv1: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        et1=findViewById(R.id.txt_num1)
        et2=findViewById(R.id.txt_num2)
        tv1=findViewById(R.id.tv_resultado)

    }
    //sumar
    fun sumar(view: View){
        val valor1=et1.text.toString()
        val valor2=et2.text.toString()
        if(valor1!=""&&valor2!=""){
            val num1=valor1.toInt()
            val num2=valor2.toInt()
            val suma= num1+num2
            val resultado=suma.toString()
            tv1.text=resultado
        }
        else{
            Toast.makeText(this, "ingrese los valores en los campos", Toast.LENGTH_SHORT).show()
        }
    }//restar
    fun restar(view: View){
        val valor1=et1.text.toString()
        val valor2=et2.text.toString()
        if(valor1!=""&&valor2!=""){
            val num1=valor1.toInt()
            val num2=valor2.toInt()
            val resta= num1-num2
            val resultado=resta.toString()
            tv1.text=resultado
        }
        else{
            Toast.makeText(this, "ingrese los valores en los campos", Toast.LENGTH_SHORT).show()
        }
    }
    //multiplicar
    fun multiplicar(view: View){
        val valor1=et1.text.toString()
        val valor2=et2.text.toString()
        if(valor1!=""&&valor2!=""){
            val num1=valor1.toInt()
            val num2=valor2.toInt()
            val multiplica= num1*num2
            val resultado=multiplica.toString()
            tv1.text=resultado
        }
        else{
            Toast.makeText(this, "ingrese los valores en los campos", Toast.LENGTH_SHORT).show()
        }
    }
    //dividir
    fun dividir(view: View){
        val valor1=et1.text.toString()
        val valor2=et2.text.toString()
        if(valor1!=""&&valor2!=""){
            val num1=valor1.toFloat()
            val num2=valor2.toFloat()
            val divide= num1/num2
            val resultado=divide.toString()
            tv1.text=resultado
        }
        else{
            Toast.makeText(this, "ingrese los valores en los campos", Toast.LENGTH_SHORT).show()
        }
    }
}
